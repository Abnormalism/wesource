/* BEGIN NAV */

const burgerBtn = document.querySelector(".burger-btn");
const mobileNav = document.querySelector(".mobile-nav");
const navLink = document.querySelectorAll(".nav-link");

burgerBtn.addEventListener("click", () => {
  navHeightControl();
});

navLink.forEach((link) => {
  link.addEventListener("click", (e) => {
    navLink.forEach((link) => {
      link.classList.remove("nav-active");
    });

    const currentTargetLink = e.currentTarget;

    currentTargetLink.classList.add("nav-active");

    navHeightControl();
  });
});

function navHeightControl() {
  const mobileNavClasslist = mobileNav.classList;

  return mobileNavClasslist.contains("h-[4rem]")
    ? mobileNavClasslist.replace("h-[4rem]", "h-[13]")
    : mobileNavClasslist.replace("h-[13]", "h-[4rem]");
}
/* END NAV */

/* BEGIN TOP BTN */
const topBtn = document.querySelector(".to-top");
const services = document.getElementById("services");

window.addEventListener("scroll", () => {
  const showTopBtn = services.getBoundingClientRect().top;

  showTopBtn <= 200
    ? topBtn.classList.remove("scale-0")
    : topBtn.classList.add("scale-0");
});

/* END TOP BTN */

/* BEGIN GSAP ANIMATIONS */
const tl = gsap.timeline({ defaults: { duration: 0.75 } });
const intro = document.querySelector(".intro");

window.addEventListener("scroll", () => {
  console.log(true);
});
/* END GSAP ANIMATIONS */
